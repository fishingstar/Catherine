stb
===

single-file public domain (or MIT licensed) libraries for C/C++ <a name="stb_libs"></a>

Most libraries by stb, except: stb_dxt by Fabian "ryg" Giesen, stb_image_resize
by Jorge L. "VinoBS" Rodriguez, and stb_sprintf by Jeff Roberts.


library    | lastest version | category | LoC | description
--------------------- | ---- | -------- | --- | --------------------------------
